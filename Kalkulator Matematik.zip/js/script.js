function hitungLuas() {
  event.preventDefault();

  // Mengambil nilai sisi dari input
  const sisi = parseFloat(document.getElementById("sisiLuas").value);

  // Validasi input
  if (isNaN(sisi) || sisi <= 0) {
    alert("Sisi harus berupa angka positif.");
    return;
  }

  // Menghitung luas
  const luas = sisi * sisi;

  // Menampilkan hasil luas
  document.getElementById("luas").textContent = luas.toFixed(2);
  document.getElementById("hasilLuas").style.display = "block";
}

function hitungKeliling() {
  event.preventDefault();

  // Mengambil nilai sisi dari input
  const sisi = parseFloat(document.getElementById("sisiKeliling").value);

  // Validasi input
  if (isNaN(sisi) || sisi <= 0) {
    alert("Sisi harus berupa angka positif.");
    return;
  }

  // Menghitung keliling
  const keliling = 4 * sisi;

  // Menampilkan hasil keliling
  document.getElementById("keliling").textContent = keliling.toFixed(2);
  document.getElementById("hasilKeliling").style.display = "block";
}

document.getElementById("luasForm").addEventListener("submit", hitungLuas);
document
  .getElementById("kelilingForm")
  .addEventListener("submit", hitungKeliling);
